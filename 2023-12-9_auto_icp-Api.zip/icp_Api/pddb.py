from tools.infer.predict_det import TextDetector
from tools.infer.predict_rec import TextRecognizer
import tools.infer.utility as utility
from ppocr.utils.utility import get_image_file_list, check_and_read
from paddleocr import PaddleOCR
import numpy as np
import cv2
import time
import json
import traceback

class myocr():
    def __init__(self) -> None:
        self.args = utility.parse_args()
        self.args.rec_model_dir = './recmodel/'
        self.args.det_model_dir = './detmodel/'
        self.args.rec_image_shape = '3,64,64'
        self.args.use_gpu = False
        self.ocr = PaddleOCR(
            rec_model_dir="./recmodel/",
            lang='ch'
        )


    # 用于检测ibig文字
    def autodet(self,img):
        args = self.args
        image_file_list = get_image_file_list(img)
        text_detector = TextDetector(args)
        
        total_time = 0

        if args.warmup:
            img = np.random.uniform(0, 255, [640, 640, 3]).astype(np.uint8)
            for i in range(2):
                res = text_detector(img)

        save_results = []
        for idx, image_file in enumerate(image_file_list):
            img, flag_gif, flag_pdf = check_and_read(image_file)
            if not flag_gif and not flag_pdf:
                img = cv2.imread(image_file)
            if not flag_pdf:
                if img is None:
                    print("error in loading image:{}".format(image_file))
                    continue
                imgs = [img]
            else:
                page_num = args.page_num
                if page_num > len(img) or page_num == 0:
                    page_num = len(img)
                imgs = img[:page_num]
            for index, img in enumerate(imgs):
                st = time.time()
                dt_boxes, _ = text_detector(img)
                elapse = time.time() - st
                total_time += elapse

                data = json.dumps([x.tolist() for x in dt_boxes])
                save_results.append(data)
        # 绘制检测图像,想看检测效果可以取消注释这三行
        # src_im = utility.draw_text_det_res(dt_boxes, img)
        # cv2.imshow("s",src_im)
        # cv2.waitKey(0)
        return json.loads(save_results[0])

    # 用于识别ibig和isma文字
    # 暂时改用ocr，正在准备6w大数据重新训练识别模型
    def autorec(self,img):
        args = self.args
        image_file_list = get_image_file_list(img)
        text_recognizer = TextRecognizer(args)
        valid_image_file_list = []
        img_list = []
        for image_file in image_file_list:
            img, flag, _ = check_and_read(image_file)
            if not flag:
                img = cv2.imread(image_file)
            if img is None:
                print("error in loading image:{}".format(image_file))
                continue
            valid_image_file_list.append(image_file)
            img_list.append(img)
        try:
            rec_res, _ = text_recognizer(img_list)
            # jiance = self.ocr.ocr(img,det=False)
        except Exception as E:
            print(traceback.format_exc())
            print(E)
            exit()
        dl = []
        for ino in range(len(img_list)):
            dl.append(rec_res[ino])
        return dl

    def autoocr(self,ibig,isma):
        bigres = self.autodet(ibig)
        ibigimage = cv2.imread(ibig)
        if len(bigres) < 4:
            return False,None
        
        dl = {}
        for i, coord in enumerate(bigres):
            pts = np.float32(coord)
            dst_size = (int(max(pts[:,0]) - min(pts[:,0])), int(max(pts[:,1]) - min(pts[:,1])))
            dst_pts = np.float32([[0, 0], [dst_size[0], 0], [dst_size[0], dst_size[1]], [0, dst_size[1]]])
            M = cv2.getPerspectiveTransform(pts, dst_pts)
            cropped_img = cv2.warpPerspective(ibigimage, M, dst_size)
            jiance = self.ocr.ocr(cropped_img,det=False)

            center_x = (coord[0][0] + coord[1][0] + coord[2][0] + coord[3][0]) / 4
            center_y = (coord[0][1] + coord[1][1] + coord[2][1] + coord[3][1]) / 4

            dl[jiance[0][0][0]] = {'x':int(center_x), 'y':int(center_y)}
 
        jiance = self.ocr.ocr(isma,det=False)

        if len(jiance) < 1:
            return False,None
        res = jiance[0][0][0][6::2]
        hb = []
        for i in res:
            if i not in dl:
                return False,None
            else:
                hb.append(dl[i])
        return True,hb